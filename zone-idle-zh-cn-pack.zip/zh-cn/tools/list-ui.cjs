const fs = require('fs');
const path = require('path');
const { parseCsv } = require('./extract.cjs');
const ROOT = path.resolve(__dirname, '..');
const rows = parseCsv(fs.readFileSync(path.join(ROOT, 'table.csv'), 'utf8'))
  .filter((r) => r.kind.startsWith('ui') && !r.zh);
const from = Number(process.argv[2] || 0);
const to = Number(process.argv[3] || 250);
for (let i = from; i < Math.min(to, rows.length); i++) {
  console.log(i + '\t' + rows[i].en.replace(/\n/g, '\\n'));
}
console.error('[total untranslated ui]', rows.length);
