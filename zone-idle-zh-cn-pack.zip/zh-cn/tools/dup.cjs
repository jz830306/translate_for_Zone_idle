// 查找 table.csv 中重复原文（同一 en 出现多行），并列出其 kind / 是否已译
const fs = require('fs');
const path = require('path');
const { parseCsv } = require('./extract.cjs');

const ROOT = path.resolve(__dirname, '..');
const rows = parseCsv(fs.readFileSync(path.join(ROOT, 'table.csv'), 'utf8'));
const norm = (s) => s.replace(/\u00a0/g, ' ').replace(/\s+/g, ' ').trim();
const probe = process.argv[2];
const groups = new Map();
for (const r of rows) {
  const k = norm(r.en);
  if (!groups.has(k)) groups.set(k, []);
  groups.get(k).push(r);
}
let n = 0;
for (const [k, list] of groups) {
  if (list.length < 2) continue;
  if (probe && !k.includes(probe)) continue;
  n++;
  if (n <= 15) {
    console.log('▸ ' + k.slice(0, 70));
    list.forEach((r) => console.log('    ' + r.id + '  ' + r.kind + '  ' + (r.zh ? '[有译]' : '[空]')));
  }
}
console.log('重复原文组数：' + [...groups.values()].filter((l) => l.length > 1).length + (probe ? '（匹配 ' + n + ' 组）' : ''));
