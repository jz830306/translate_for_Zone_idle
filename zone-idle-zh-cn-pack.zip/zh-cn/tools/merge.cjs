#!/usr/bin/env node
/**
 * merge.cjs — 把 batches/*.json 里的译文合并进 table.csv
 *   node tools/merge.cjs
 * batch 文件格式：{ "英文原文": "中文译文", ... } 或 { "0": "...", } 均不支持，必须用原文做键
 */
const fs = require('fs');
const path = require('path');
const { parseCsv, toCsv } = require('./extract.cjs');

const ROOT = path.resolve(__dirname, '..');
const CSV = path.join(ROOT, 'table.csv');
const DIR = path.join(ROOT, 'batches');

const rows = parseCsv(fs.readFileSync(CSV, 'utf8'));
const norm = (s) => s.replace(/\u00a0/g, ' ').replace(/\s+/g, ' ').trim();
// 二次宽松归一：弯引号/撇号与直引号视为同一字符（bundle 里混用 ’ 与 '）
const norm2 = (s) => norm(s).replace(/[\u2018\u2019]/g, "'").replace(/[\u201c\u201d]/g, '"');
const byEn = new Map(rows.map((r) => [norm(r.en), r]));
const byEn2 = new Map(rows.map((r) => [norm2(r.en), r]));

let applied = 0;
let loose = 0;
const unknown = [];
const files = fs.existsSync(DIR) ? fs.readdirSync(DIR).filter((f) => f.endsWith('.json')).sort() : [];
for (const f of files) {
  const data = JSON.parse(fs.readFileSync(path.join(DIR, f), 'utf8'));
  for (const [en, zh] of Object.entries(data)) {
    if (en.startsWith('_')) continue;
    let row = byEn.get(norm(en));
    if (!row) {
      row = byEn2.get(norm2(en));
      if (row) loose++;
    }
    if (!row) { unknown.push(f + ' :: ' + en); continue; }
    row.zh = zh;
    applied++;
  }
}

fs.writeFileSync(CSV, toCsv(rows), 'utf8');
const done = rows.filter((r) => r.zh && r.zh.trim()).length;
console.log(`合并 ${files.length} 个批次，写入 ${applied} 条；总进度 ${done}/${rows.length}（${((done / rows.length) * 100).toFixed(1)}%）`);
if (unknown.length) {
  console.log(`⚠ ${unknown.length} 条原文在表中不存在（拼写/大小写不符）：`);
  console.log(unknown.slice(0, 20).join('\n'));
}
