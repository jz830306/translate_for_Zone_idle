// 扫描 bundle：带 Operator 的物品名、以及 Anti-Rad 物品名
const lib = require('./asar-lib.cjs');
const js = lib.read('../resources/app.asar', 'dist/assets/index-D_XPUTSw.js').toString('utf8');

function scan(re, label) {
  const s = new Set();
  let m;
  while ((m = re.exec(js))) s.add(m[1]);
  console.log('--- ' + label + ' (' + s.size + ') ---');
  console.log([...s].sort().join('\n'));
}

scan(/name:"([^"]*Operator[^"]*)"/g, 'name 含 Operator');
scan(/name:"([^"]*Anti-Rad[^"]*)"/g, 'name 含 Anti-Rad');
