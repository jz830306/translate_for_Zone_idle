// mkzip.cjs —— 无依赖标准 ZIP 生成（deflate + central directory，UTF-8 文件名标志）
// 用法: node mkzip.cjs <输出.zip> <清单文件，每行 "zip内路径<TAB>磁盘路径">
const fs = require('fs');
const path = require('path');
const zlib = require('zlib');

const [outFile, listFile] = process.argv.slice(2);
if (!outFile || !listFile) {
  console.error('用法: node mkzip.cjs <输出.zip> <清单文件>');
  process.exit(1);
}

const entries = fs
  .readFileSync(listFile, 'utf8')
  .split(/\r?\n/)
  .map((l) => l.trim())
  .filter((l) => l && !l.startsWith('#'))
  .map((l) => {
    const i = l.indexOf('\t');
    return { name: l.slice(0, i).replace(/\\/g, '/'), file: l.slice(i + 1) };
  });

const localParts = [];
const centralParts = [];
let offset = 0;

function dosDateTime(d) {
  const time = ((d.getHours() & 0x1f) << 11) | ((d.getMinutes() & 0x3f) << 5) | ((d.getSeconds() / 2) & 0x1f);
  const date = (((d.getFullYear() - 1980) & 0x7f) << 9) | (((d.getMonth() + 1) & 0xf) << 5) | (d.getDate() & 0x1f);
  return { time, date };
}

for (const e of entries) {
  const data = fs.readFileSync(e.file);
  const { time, date } = dosDateTime(fs.statSync(e.file).mtime);
  const nameBuf = Buffer.from(e.name, 'utf8');
  const crc32 = crc32Of(data);
  const compressed = zlib.deflateRawSync(data, { level: 9 });
  const useDeflate = compressed.length < data.length;

  const lh = Buffer.alloc(30);
  lh.writeUInt32LE(0x04034b50, 0);
  lh.writeUInt16LE(20, 4); // version needed
  lh.writeUInt16LE(0x0800, 6); // UTF-8 名字标志
  lh.writeUInt16LE(useDeflate ? 8 : 0, 8);
  lh.writeUInt16LE(time, 10);
  lh.writeUInt16LE(date, 12);
  lh.writeUInt32LE(crc32, 14);
  lh.writeUInt32LE(useDeflate ? compressed.length : data.length, 18);
  lh.writeUInt32LE(data.length, 22);
  lh.writeUInt16LE(nameBuf.length, 26);
  lh.writeUInt16LE(0, 28);
  localParts.push(lh, nameBuf, useDeflate ? compressed : data);

  const ch = Buffer.alloc(46);
  ch.writeUInt32LE(0x02014b50, 0);
  ch.writeUInt16LE(20, 4); // version made by
  ch.writeUInt16LE(20, 6); // version needed
  ch.writeUInt16LE(0x0800, 8);
  ch.writeUInt16LE(useDeflate ? 8 : 0, 10);
  ch.writeUInt16LE(time, 12);
  ch.writeUInt16LE(date, 14);
  ch.writeUInt32LE(crc32, 16);
  ch.writeUInt32LE(useDeflate ? compressed.length : data.length, 20);
  ch.writeUInt32LE(data.length, 24);
  ch.writeUInt16LE(nameBuf.length, 28);
  ch.writeUInt32LE(offset, 42);
  centralParts.push(ch, nameBuf);

  offset += lh.length + nameBuf.length + (useDeflate ? compressed.length : data.length);
}

const central = Buffer.concat(centralParts);
const eocd = Buffer.alloc(22);
eocd.writeUInt32LE(0x06054b50, 0);
eocd.writeUInt16LE(entries.length, 8);
eocd.writeUInt16LE(entries.length, 10);
eocd.writeUInt32LE(central.length, 12);
eocd.writeUInt32LE(offset, 16);

fs.writeFileSync(outFile, Buffer.concat([...localParts, central, eocd]));
console.log('打包 ' + entries.length + ' 个条目 → ' + outFile + '（' + fs.statSync(outFile).size + ' 字节）');

function crc32Of(buf) {
  let table = crc32Of.table;
  if (!table) {
    table = crc32Of.table = new Int32Array(256);
    for (let n = 0; n < 256; n++) {
      let c = n;
      for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
      table[n] = c;
    }
  }
  let crc = -1;
  for (let i = 0; i < buf.length; i++) crc = (crc >>> 8) ^ table[(crc ^ buf[i]) & 0xff];
  return (crc ^ -1) >>> 0;
}
