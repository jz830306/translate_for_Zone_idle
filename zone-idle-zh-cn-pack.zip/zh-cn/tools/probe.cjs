// 对比 batch 键与 table.csv 原文的字符级差异
const fs = require('fs');
const path = require('path');
const { parseCsv } = require('./extract.cjs');

const ROOT = path.resolve(__dirname, '..');
const rows = parseCsv(fs.readFileSync(path.join(ROOT, 'table.csv'), 'utf8'));
const probe = process.argv[2] || 'anomaly detector';
const row = rows.find((r) => r.en.includes(probe));
if (!row) { console.log('未找到含 "' + probe + '" 的条目'); process.exit(0); }
const en = row.en;
console.log('原文长度 ' + en.length + '  wordId=' + row.id);
// 打印所有非 ASCII 字符
for (let i = 0; i < en.length; i++) {
  const c = en.charCodeAt(i);
  if (c > 127) console.log('  @' + i + ' U+' + c.toString(16).toUpperCase().padStart(4, '0') + ' ' + JSON.stringify(en.slice(Math.max(0, i - 12), i + 12)));
}
console.log('JSON: ' + JSON.stringify(en.slice(0, 120)));
