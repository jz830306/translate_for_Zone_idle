// 通过 CDP 操作运行中的游戏页面（Node 22 自带 WebSocket）
// 用法:
//   node tools/cdp.cjs eval "<js 表达式>"
//   node tools/cdp.cjs shot <输出png路径>
//   node tools/cdp.cjs text            // 打印 innerText 前 N 行
const fs = require('fs');

const PORT = process.env.CDP_PORT || 9223;

async function pageWs() {
  const list = await (await fetch('http://127.0.0.1:' + PORT + '/json/list')).json();
  const page = list.find((t) => t.type === 'page');
  if (!page) throw new Error('找不到页面');
  return page.webSocketDebuggerUrl;
}

function connect(url) {
  const ws = new WebSocket(url);
  let id = 0;
  const waiting = new Map();
  ws.addEventListener('message', (ev) => {
    const msg = JSON.parse(ev.data);
    if (msg.id && waiting.has(msg.id)) {
      const { resolve, reject } = waiting.get(msg.id);
      waiting.delete(msg.id);
      msg.error ? reject(new Error(JSON.stringify(msg.error))) : resolve(msg.result);
    }
  });
  const ready = new Promise((res, rej) => {
    ws.addEventListener('open', res);
    ws.addEventListener('error', rej);
  });
  const send = (method, params) =>
    new Promise((resolve, reject) => {
      const mid = ++id;
      waiting.set(mid, { resolve, reject });
      ws.send(JSON.stringify({ id: mid, method, params: params || {} }));
    });
  return { ws, ready, send };
}

(async () => {
  const [cmd, arg] = process.argv.slice(2);
  const wsUrl = await pageWs();
  const { ws, ready, send } = connect(wsUrl);
  await ready;
  await send('Runtime.enable');

  if (cmd === 'eval') {
    const r = await send('Runtime.evaluate', {
      expression: arg,
      returnByValue: true,
      awaitPromise: true,
    });
    console.log(JSON.stringify(r.result && r.result.value !== undefined ? r.result.value : r, null, 1));
  } else if (cmd === 'shot') {
    const r = await send('Page.captureScreenshot', { format: 'png' });
    fs.writeFileSync(arg, Buffer.from(r.data, 'base64'));
    console.log('已保存 ' + arg);
  } else if (cmd === 'reload') {
    await send('Page.enable');
    await send('Page.reload', { ignoreCache: true });
    console.log('已刷新');
  } else if (cmd === 'text') {
    const r = await send('Runtime.evaluate', {
      expression: 'document.body.innerText',
      returnByValue: true,
    });
    console.log(r.result.value);
  }
  ws.close();
})().catch((e) => {
  console.error('CDP 失败: ' + e.message);
  process.exit(1);
});
