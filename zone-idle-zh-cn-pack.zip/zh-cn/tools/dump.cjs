// 导出某一 kind 的未译条目，供人工/批量翻译使用。
// 用法: node tools/dump.cjs <kind> [from] [to]
// 输出: pending/<kind>.txt  （编号 + 长度 + 原文，段落用空行分隔）
//       pending/<kind>.json （[{i, en}]）
const fs = require('fs');
const path = require('path');
const { parseCsv } = require('./extract.cjs');

const ROOT = path.resolve(__dirname, '..');
const OUT = path.join(ROOT, 'pending');
fs.mkdirSync(OUT, { recursive: true });

const kind = process.argv[2] || 'data';
const from = Number(process.argv[3] || 0);
const to = Number(process.argv[4] || 1e9);

const rows = parseCsv(fs.readFileSync(path.join(ROOT, 'table.csv'), 'utf8'))
  .filter((r) => r.kind.split('+').includes(kind) && !r.zh);

const slice = rows.slice(from, to);
const lines = [];
slice.forEach((r, i) => {
  lines.push('#' + (from + i) + ' [' + r.en.length + '] ' + r.en.replace(/\n/g, '\\n'));
});
fs.writeFileSync(path.join(OUT, kind + '.txt'), lines.join('\n\n') + '\n', 'utf8');
fs.writeFileSync(
  path.join(OUT, kind + '.json'),
  JSON.stringify(slice.map((r, i) => ({ i: from + i, en: r.en })), null, 1),
  'utf8'
);
console.log('[导出 ' + kind + '] ' + slice.length + ' / 共 ' + rows.length + ' 条未译');
