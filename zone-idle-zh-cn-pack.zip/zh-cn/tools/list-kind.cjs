const fs = require('fs');
const path = require('path');
const { parseCsv } = require('./extract.cjs');
const ROOT = path.resolve(__dirname, '..');
const kind = process.argv[2] || 'data';
const from = Number(process.argv[3] || 0);
const to = Number(process.argv[4] || 100);
const rows = parseCsv(fs.readFileSync(path.join(ROOT, 'table.csv'), 'utf8'))
  .filter((r) => r.kind.split('+').includes(kind) && !r.zh);
for (let i = from; i < Math.min(to, rows.length); i++) console.log(rows[i].en.replace(/\n/g, '\\n'));
console.error('[剩余 ' + kind + '] ' + rows.length);
