#!/usr/bin/env node
/**
 * patch.cjs — 把汉化加载器挂进游戏（唯一改动 asar 的动作）
 *
 *   node tools/patch.cjs            安装/更新（自动备份原包）
 *   node tools/patch.cjs --restore  还原原版
 *   node tools/patch.cjs --check    只检查当前状态
 *
 * 改动内容仅两处：
 *   1. dist/index.html 增加一行 <script src="./zh-cn/loader.js">
 *   2. 新增文件 dist/zh-cn/loader.js
 * 其余字节原样复制，不重编码、不压缩。
 */
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const lib = require('./asar-lib.cjs');

const ROOT = path.resolve(__dirname, '..');
const GAME = path.resolve(ROOT, '..');
const ASAR = path.join(GAME, 'resources', 'app.asar');
const BACKUP = path.join(GAME, 'resources', 'app.asar.zh-backup');
const TMP = path.join(GAME, 'resources', 'app.asar.tmp');
const LOADER = path.join(ROOT, 'app', 'loader.js');
const INDEX = 'dist/index.html';
const LOADER_IN_ASAR = 'dist/zh-cn/loader.js';
const TAG = '<script src="./zh-cn/loader.js"></script>';
const args = process.argv.slice(2);

function sha1(p) {
  return crypto.createHash('sha1').update(fs.readFileSync(p)).digest('hex');
}

function state() {
  const hasBackup = fs.existsSync(BACKUP);
  const html = lib.read(ASAR, INDEX).toString('utf8');
  return { hasBackup, patched: html.includes(TAG) };
}

if (args.includes('--check')) {
  const s = state();
  console.log({ asar: ASAR, size: fs.statSync(ASAR).size, backup: s.hasBackup, patched: s.patched });
  process.exit(0);
}

if (args.includes('--restore')) {
  if (!fs.existsSync(BACKUP)) {
    console.error('没有备份可还原：' + BACKUP);
    process.exit(1);
  }
  fs.copyFileSync(BACKUP, ASAR);
  console.log('已还原原版 app.asar（' + fs.statSync(ASAR).size + ' 字节）');
  console.log('词表仍在 resources/zh-cn/，删除该目录即可彻底清除');
  process.exit(0);
}

// ---- 安装 ----
if (!fs.existsSync(BACKUP)) {
  fs.copyFileSync(ASAR, BACKUP);
  console.log('已备份原包 → ' + BACKUP);
  console.log('  校验 sha1', sha1(BACKUP));
}

let html = lib.read(ASAR, INDEX).toString('utf8');
if (!html.includes(TAG)) {
  html = html.replace(/<html lang="[^"]*"/, '<html lang="zh-CN"');
  if (!/lang="zh-CN"/.test(html)) html = html.replace('<html', '<html lang="zh-CN"');
  html = html.replace(/(\s*)<script type="module"/, '\n  ' + TAG + '$1<script type="module"');
  if (!html.includes(TAG)) throw new Error('无法定位注入点，index.html 结构已变');
  console.log('已注入 script 标签');
} else {
  console.log('index.html 已含注入标签，跳过');
}

const loader = fs.readFileSync(LOADER);
lib.repack(ASAR, TMP, { [INDEX]: Buffer.from(html, 'utf8'), [LOADER_IN_ASAR]: loader });

// 校验新包可读
const check = lib.list(TMP);
const entry = check.find((f) => f.path === INDEX);
if (!entry || entry.size !== Buffer.byteLength(html)) throw new Error('新包自检失败');

// 替换：优先 rename；若被占用（Steam/杀软以无 FILE_SHARE_DELETE 方式持有句柄）则原地覆写
let done = false;
try {
  fs.renameSync(ASAR, ASAR + '.old');
  try {
    fs.renameSync(TMP, ASAR);
    done = true;
  } catch (e) {
    fs.renameSync(ASAR + '.old', ASAR); // 回滚
    throw e;
  }
  fs.unlinkSync(ASAR + '.old');
} catch (err) {
  if (!/EBUSY|EPERM|EACCES/.test(err.code || '')) throw err;
  console.log('重命名被占用（' + err.code + '），改为原地覆写');
  overwriteInPlace(TMP, ASAR);
  fs.unlinkSync(TMP);
  done = true;
}

function overwriteInPlace(from, to) {
  const src = fs.openSync(from, 'r');
  const dst = fs.openSync(to, 'r+');
  const size = fs.fstatSync(src).size;
  const CHUNK = 8 * 1024 * 1024;
  const buf = Buffer.alloc(CHUNK);
  let pos = 0;
  while (pos < size) {
    const n = fs.readSync(src, buf, 0, Math.min(CHUNK, size - pos), pos);
    if (n <= 0) throw new Error('读取源文件失败');
    let off = 0;
    while (off < n) off += fs.writeSync(dst, buf, off, n - off, pos + off);
    pos += n;
  }
  fs.ftruncateSync(dst, size);
  fs.fsyncSync(dst);
  fs.closeSync(src);
  fs.closeSync(dst);
}

console.log('打包完成：' + fs.statSync(ASAR).size + ' 字节，文件数 ' + check.length);
console.log('下一步：node tools/build.cjs 生成词表，然后启动游戏');
