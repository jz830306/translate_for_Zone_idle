#!/usr/bin/env node
/**
 * build.cjs — table.csv → resources/zh-cn/table.json（运行时词表）
 *   node tools/build.cjs
 * 只导出有译文的条目；enabled 开关在 table.json 顶部手动维护
 */
const fs = require('fs');
const path = require('path');
const { parseCsv } = require('./extract.cjs');

const ROOT = path.resolve(__dirname, '..');
const CSV = path.join(ROOT, 'table.csv');
const RULES = path.join(ROOT, 'rules.json');
const OUT = path.join(ROOT, '..', 'resources', 'zh-cn', 'table.json');

const rows = parseCsv(fs.readFileSync(CSV, 'utf8'));
const norm = (s) => s.replace(/\u00a0/g, ' ').replace(/\s+/g, ' ').trim();
// 弯引号折叠：bundle 里 ’ “ ” 与 ' " 混用，两种形态都写进词表，DOM 侧无需感知
const norm2 = (s) => norm(s).replace(/[\u2018\u2019]/g, "'").replace(/[\u201c\u201d]/g, '"');
const entries = {};
const seen = new Map();
const put = (key, zh, origin) => {
  if (seen.has(key)) {
    if (seen.get(key) !== zh) console.warn('⚠ 同一原文译文冲突：', origin);
    return;
  }
  seen.set(key, zh);
  entries[key] = zh;
  const lower = key.toLowerCase();
  if (lower !== key && !(lower in entries) && !seen.has(lower)) entries['~' + lower] = zh;
};
for (const r of rows) {
  if (!r.zh || !r.zh.trim() || !r.en) continue;
  const key = norm(r.en);
  put(key, r.zh, key);
  const key2 = norm2(r.en);
  if (key2 !== key) put(key2, r.zh, key);
}

const rules = fs.existsSync(RULES) ? JSON.parse(fs.readFileSync(RULES, 'utf8')) : [];

// 补充词条：游戏内运行时拼出、不在 table.csv 里的短名（如缩略名映射的产物）
const EXTRA = path.join(ROOT, 'table-extra.json');
if (fs.existsSync(EXTRA)) {
  const extra = JSON.parse(fs.readFileSync(EXTRA, 'utf8'));
  for (const [en, zh] of Object.entries(extra)) {
    if (en.startsWith('_')) continue;
    put(norm(en), zh, en);
    const k2 = norm2(en);
    if (k2 !== norm(en)) put(k2, zh, en);
  }
  console.log('  另合并补充词条 ' + Object.keys(extra).filter((k) => !k.startsWith('_')).length + ' 条（table-extra.json）');
}
const payload = {
  _readme: '外挂汉化词表。entries = 英文原文 → 中文译文；rules = 带变量的动态串。改完重启游戏生效，无需重新打包。',
  enabled: true,
  entries,
  rules: rules.rules || rules,
};

fs.mkdirSync(path.dirname(OUT), { recursive: true });
fs.writeFileSync(OUT, JSON.stringify(payload, null, 1), 'utf8');

const total = rows.length;
const done = rows.filter((r) => r.zh && r.zh.trim()).length;
console.log(`词表输出 → ${OUT}`);
console.log(`覆盖 ${done}/${total} 条（${((done / total) * 100).toFixed(1)}%），规则 ${payload.rules.length} 条`);
const byKind = {};
for (const r of rows) {
  const k = r.kind.split('+')[0];
  byKind[k] = byKind[k] || { done: 0, all: 0 };
  byKind[k].all++;
  if (r.zh && r.zh.trim()) byKind[k].done++;
}
for (const k of Object.keys(byKind).sort()) {
  const v = byKind[k];
  console.log(`  ${k.padEnd(6)} ${String(v.done).padStart(5)}/${String(v.all).padEnd(5)} ${((v.done / v.all) * 100).toFixed(0)}%`);
}
