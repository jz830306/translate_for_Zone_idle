// 诊断：模拟 merge 的查表过程，检查某条原文为何未写入 zh
const fs = require('fs');
const path = require('path');
const { parseCsv } = require('./extract.cjs');

const ROOT = path.resolve(__dirname, '..');
const rows = parseCsv(fs.readFileSync(path.join(ROOT, 'table.csv'), 'utf8'));
const norm = (s) => s.replace(/\u00a0/g, ' ').replace(/\s+/g, ' ').trim();
const byEn = new Map(rows.map((r) => [norm(r.en), r]));
const probe = process.argv[2];

const hits = rows.filter((r) => r.en.includes(probe));
console.log('csv 命中行数 ' + hits.length);
hits.forEach((r) => console.log('  ' + r.id + ' kind=' + r.kind + ' zh=' + JSON.stringify(r.zh) + ' enLen=' + r.en.length));

const file = process.argv[3];
if (file) {
  const batch = JSON.parse(fs.readFileSync(path.join(ROOT, 'batches', file), 'utf8'));
  const keys = Object.keys(batch).filter((k) => k.includes(probe));
  console.log('batch 命中键数 ' + keys.length);
  keys.forEach((k) => {
    const target = byEn.get(norm(k));
    console.log('  keyLen=' + k.length + ' -> ' + (target ? target.id + ' zh=' + JSON.stringify(target.zh) : '查无此条'));
  });
}
