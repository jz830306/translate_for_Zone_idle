#!/usr/bin/env node
/**
 * asar-lib.cjs — 极简 asar 读写库（无外部依赖）
 *   read(src, path)            → Buffer
 *   list(src)                  → [{path,size,unpacked}]
 *   repack(src, dest, overrides) → 以原包为底，替换/新增条目，其余字节流式原样复制
 */
const fs = require('fs');

function open(src) {
  if (!fs.existsSync(src)) {
    throw new Error(
      '找不到 ' + src + '\n' +
      '这个工具必须在游戏目录里运行（zh-cn/ 要和 resources/app.asar 同级）。\n' +
      '如果你只是要更新词表，用 tools/build.cjs 就够了，不需要 app.asar。'
    );
  }
  const fd = fs.openSync(src, 'r');
  const head = Buffer.alloc(16);
  fs.readSync(fd, head, 0, 16, 0);
  const jsonLen = head.readUInt32LE(12);
  const hb = Buffer.alloc(jsonLen);
  fs.readSync(fd, hb, 0, jsonLen, 16);
  return {
    fd,
    header: JSON.parse(hb.toString('utf8')),
    dataBase: 8 + head.readUInt32LE(4),
    size: fs.statSync(src).size,
  };
}

function walk(node, p, cb) {
  for (const k of Object.keys(node.files || {})) {
    const c = node.files[k];
    const np = p ? p + '/' + k : k;
    if (c.files) walk(c, np, cb);
    else cb(np, c);
  }
}

function list(src) {
  const a = typeof src === 'string' ? open(src) : src;
  const out = [];
  walk(a.header, '', (p, e) => out.push({ path: p, size: e.size, unpacked: !!e.unpacked }));
  if (a.fd !== undefined && typeof src === 'string') fs.closeSync(a.fd);
  return out;
}

function read(src, p) {
  const a = typeof src === 'string' ? open(src) : src;
  let cur = a.header;
  for (const seg of p.split('/')) {
    cur = cur.files && cur.files[seg];
    if (!cur) throw new Error('not found: ' + p);
  }
  if (cur.files) throw new Error('is a directory: ' + p);
  const buf = Buffer.alloc(cur.size);
  fs.readSync(a.fd, buf, 0, cur.size, a.dataBase + Number(cur.offset));
  if (typeof src === 'string') fs.closeSync(a.fd);
  return buf;
}

const pad4 = (n) => (n % 4 === 0 ? n : n + (4 - (n % 4)));
// Chromium pickle 以整个 pickle（含自身 4 字节长度字段）为对齐单位：
// 头部总长 = pad4(4 + 4 + jsonLen)，其中前 8 字节是 (4, 头部总长)
const headerBlockLen = (jsonLen) => pad4(8 + jsonLen);

function repack(src, dest, overrides) {
  const a = open(src);
  const header = JSON.parse(JSON.stringify(a.header));

  // 1) 在原 header 树上挂 overrides（新增目录按需创建）
  for (const p of Object.keys(overrides)) {
    const segs = p.split('/');
    let cur = header;
    for (let i = 0; i < segs.length - 1; i++) {
      const s = segs[i];
      if (!cur.files[s]) cur.files[s] = { files: {} };
      if (!cur.files[s].files) throw new Error('路径冲突（文件与目录同名）: ' + p);
      cur = cur.files[s];
    }
    cur.files[segs[segs.length - 1]] = { size: overrides[p].length, offset: '0' };
  }

  // 2) 布局：保持原顺序，overrides 覆盖的用新内容，其余引用原 offset
  const entries = [];
  walk(a.header, '', (p, e) => entries.push(p));
  const layout = [];
  for (const p of entries) {
    if (overrides[p]) continue;
    const orig = lookup(a.header, p);
    if (orig.unpacked) { lookup(header, p).unpacked = true; delete lookup(header, p).offset; continue; }
    layout.push({ path: p, entry: lookup(header, p), srcOff: Number(orig.offset), size: orig.size });
  }
  for (const p of Object.keys(overrides)) {
    layout.push({ path: p, entry: lookup(header, p), buf: overrides[p], size: overrides[p].length });
  }

  // 3) 迭代到 header 长度稳定（offset 字符串长度会影响 JSON 长度）
  let json = null;
  for (let pass = 0; pass < 6; pass++) {
    let cursor = 0;
    for (const it of layout) {
      it.entry.offset = String(cursor);
      it.entry.size = it.buf ? it.buf.length : it.size;
      cursor += it.entry.size;
    }
    const next = JSON.stringify(header);
    if (next === json) break;
    json = next;
  }

  // 4) 落盘：外层 pickle(4, headerBlock) → 内层 pickle(headerBlock-4, jsonLen, json, pad)
  const jsonBuf = Buffer.from(json, 'utf8');
  const headerBlock = headerBlockLen(jsonBuf.length);
  const padLen = headerBlock - 8 - jsonBuf.length;
  if (padLen < 0 || padLen > 3) throw new Error('头部对齐计算异常: padLen=' + padLen);

  const prefix = Buffer.alloc(8);
  prefix.writeUInt32LE(4, 0);
  prefix.writeUInt32LE(headerBlock, 4);
  const innerSize = Buffer.alloc(4);
  innerSize.writeUInt32LE(headerBlock - 4, 0);
  const lenBuf = Buffer.alloc(4);
  lenBuf.writeUInt32LE(jsonBuf.length, 0);

  const out = fs.openSync(dest, 'w');
  fs.writeSync(out, prefix);
  fs.writeSync(out, innerSize);
  fs.writeSync(out, lenBuf);
  fs.writeSync(out, jsonBuf);
  if (padLen) fs.writeSync(out, Buffer.alloc(padLen));

  const ordered = layout.slice().sort((x, y) => Number(x.entry.offset) - Number(y.entry.offset));
  let cursor = 0;
  const CHUNK = 8 * 1024 * 1024;
  for (const it of ordered) {
    const off = Number(it.entry.offset);
    if (off !== cursor) throw new Error('布局空洞: ' + it.path);
    if (it.buf) {
      fs.writeSync(out, it.buf);
    } else {
      let remaining = it.size;
      let pos = a.dataBase + it.srcOff;
      const buf = Buffer.alloc(Math.min(CHUNK, Math.max(remaining, 1)));
      while (remaining > 0) {
        const n = Math.min(buf.length, remaining);
        const r = fs.readSync(a.fd, buf, 0, n, pos);
        if (r <= 0) throw new Error('读取不足: ' + it.path);
        fs.writeSync(out, buf, 0, r);
        pos += r;
        remaining -= r;
      }
    }
    cursor += it.size;
  }
  fs.closeSync(out);
  fs.closeSync(a.fd);
  return { files: ordered.length, size: 8 + headerBlock + cursor };
}

function lookup(header, p) {
  let cur = header;
  for (const seg of p.split('/')) {
    cur = cur.files && cur.files[seg];
    if (!cur) return null;
  }
  return cur;
}

module.exports = { open, list, read, repack };
