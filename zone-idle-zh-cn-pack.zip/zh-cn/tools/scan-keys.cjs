/**
 * scan-keys.cjs — 统计 bundle 里哪些 key 装着「人类可读文本」
 */
const fs = require('fs');
const s = fs.readFileSync(process.argv[2], 'utf8');
const map = new Map();
const re = /([A-Za-z_$][A-Za-z0-9_$]*):"((?:[^"\\]|\\.){2,600})"/g;
let m;
while ((m = re.exec(s))) {
  const k = m[1], v = m[2];
  if (!/[A-Za-z]/.test(v)) continue;
  if (/^(https?:|\.\/|\.\.\/|data:|#|\d)/.test(v)) continue;
  if (!map.has(k)) map.set(k, new Set());
  if (map.get(k).size < 5000) map.get(k).add(v);
}
const rows = [...map.entries()].map(([k, v]) => [k, v.size]).sort((a, b) => b[1] - a[1]);
console.log(rows.slice(0, 60).map(([k, n]) => k + '\t' + n).join('\n'));
