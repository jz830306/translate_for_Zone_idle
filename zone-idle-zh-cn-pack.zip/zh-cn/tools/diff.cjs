#!/usr/bin/env node
/**
 * diff.cjs — 逐文件比对原版备份与当前 asar，证明只改了该改的
 *   node tools/diff.cjs
 * 输出：新增/删除/大小变化/内容变化的文件清单；正常应只有
 *   新增 dist/zh-cn/loader.js、修改 dist/index.html
 */
const path = require('path');
const crypto = require('crypto');
const lib = require('./asar-lib.cjs');

const GAME = path.resolve(__dirname, '..', '..');
const A = path.join(GAME, 'resources', 'app.asar.zh-backup');
const B = path.join(GAME, 'resources', 'app.asar');

const a = lib.open(A);
const b = lib.open(B);
const listA = lib.list(a).filter((f) => !f.unpacked);
const listB = lib.list(b).filter((f) => !f.unpacked);
const mapA = new Map(listA.map((f) => [f.path, f]));
const mapB = new Map(listB.map((f) => [f.path, f]));

const added = listB.filter((f) => !mapA.has(f.path));
const removed = listA.filter((f) => !mapB.has(f.path));
const sizeChanged = [];
const modified = [];

for (const fa of listA) {
  const fb = mapB.get(fa.path);
  if (!fb) continue;
  if (fa.size !== fb.size) { sizeChanged.push({ path: fa.path, from: fa.size, to: fb.size }); continue; }
  if (fa.size === 0) continue;
  const ha = crypto.createHash('sha1').update(lib.read(a, fa.path)).digest('hex');
  const hb = crypto.createHash('sha1').update(lib.read(b, fb.path)).digest('hex');
  if (ha !== hb) modified.push(fa.path);
}

console.log('文件数（不含 unpacked）: 原版 ' + listA.length + ' → 现在 ' + listB.length);
console.log('新增 (' + added.length + '):', added.map((f) => f.path + ' (' + f.size + 'B)').join(', ') || '无');
console.log('删除 (' + removed.length + '):', removed.map((f) => f.path).join(', ') || '无');
console.log('大小变化 (' + sizeChanged.length + '):', sizeChanged.map((f) => f.path + ' ' + f.from + '→' + f.to).join(', ') || '无');
console.log('内容变化但大小相同 (' + modified.length + '):', modified.join(', ') || '无');

const htmlA = lib.read(a, 'dist/index.html').toString('utf8');
const htmlB = lib.read(b, 'dist/index.html').toString('utf8');
if (htmlA !== htmlB) {
  console.log('\ndist/index.html 差异:');
  const setA = new Set(htmlA.split('\n').map((s) => s.trim()));
  const setB = new Set(htmlB.split('\n').map((s) => s.trim()));
  for (const l of setB) if (l && !setA.has(l)) console.log('  + ' + l);
  for (const l of setA) if (l && !setB.has(l)) console.log('  - ' + l);
}

const ok = added.length <= 1 && removed.length === 0 && modified.length === 0 && sizeChanged.every((f) => f.path === 'dist/index.html');
console.log('\n结论:', ok ? '✔ 只注入了加载器，游戏本体逻辑未被改动' : '✘ 出现了非预期改动，请检查');
process.exit(ok ? 0 : 1);
