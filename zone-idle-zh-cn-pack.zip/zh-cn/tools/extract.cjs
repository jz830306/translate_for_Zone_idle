#!/usr/bin/env node
/**
 * extract.cjs — 从打包 JS 里抽出所有可翻译字符串，生成/合并翻译表
 *
 *   node tools/extract.cjs [--bundle <path>] [--out <csv>]
 *
 * 特性：
 *   - 已存在的 table.csv 里的中文译文会按 en 原文（不是行号）保留，增量抽取不会丢翻译
 *   - id = sha1(原文) 前 10 位，稳定，可做外键
 */
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const lib = require('./asar-lib.cjs');

const ROOT = path.resolve(__dirname, '..');
const ASAR = path.resolve(ROOT, '..', 'resources', 'app.asar');
const BUNDLE_IN_ASAR = 'dist/assets/index-D_XPUTSw.js';

const args = process.argv.slice(2);
const argOf = (k) => { const i = args.indexOf(k); return i >= 0 ? args[i + 1] : null; };
const OUT = argOf('--out') || path.join(ROOT, 'table.csv');

if (require.main === module) run();

function run() {
// 1. 取 bundle 内容
let bundlePath = argOf('--bundle');
let src;
if (bundlePath) {
  src = fs.readFileSync(bundlePath, 'utf8');
} else {
  src = lib.read(ASAR, BUNDLE_IN_ASAR).toString('utf8');
}

// 2. 按字段抽取。priority 越小越先翻
const FIELDS = [
  ['children', 'ui', 1],
  ['label', 'ui', 1],
  ['title', 'ui', 1],
  ['subtitle', 'ui', 1],
  ['hint', 'ui', 1],
  ['summary', 'ui', 2],
  ['text', 'ui', 2],
  ['name', 'data', 3],
  ['desc', 'data', 3],
  ['description', 'data', 3],
  ['message', 'narr', 4],
  ['successMessage', 'task', 5],
  ['failureMessage', 'task', 5],
];

const KIND_RANK = { ui: 1, data: 3, narr: 4, task: 5 };

// 统一规范化：不间断空格→空格、连续空白折叠、去首尾（loader 与 build 用同一规则）
function norm(s) {
  return s.replace(/\u00a0/g, ' ').replace(/\s+/g, ' ').trim();
}

function unescapeJs(v) {
  return v.replace(/\\(u\{[0-9a-fA-F]+\}|u[0-9a-fA-F]{4}|x[0-9a-fA-F]{2}|n|t|r|"|'|\\|\/)/g, (all, e) => {
    if (e[0] === 'u' && e[1] === '{') return String.fromCodePoint(parseInt(e.slice(2, -1), 16));
    if (e[0] === 'u' && e.length === 5) return String.fromCharCode(parseInt(e.slice(1), 16));
    if (e[0] === 'x') return String.fromCharCode(parseInt(e.slice(1), 16));
    return { n: '\n', t: '\t', r: '\r', '"': '"', "'": "'", '\\': '\\', '/': '/' }[e] ?? e;
  });
}

const entries = new Map(); // en -> { kinds:Set, hits, keyHint }
for (const [field, kind, prio] of FIELDS) {
  const re = new RegExp('(?:^|[^A-Za-z0-9_$])' + field + ':"((?:[^"\\\\]|\\\\.){1,1200})"', 'g');
  let m;
  while ((m = re.exec(src))) {
    const raw = m[1];
    if (!/[A-Za-z]/.test(raw)) continue;
    if (/^(https?:|\.\/|\.\.\/|data:|blob:)/.test(raw)) continue;
    if (/^-?[\d.]+$/.test(raw)) continue;
    const en = norm(unescapeJs(raw));
    if (en.length < 1) continue;
    if (/^#[0-9a-fA-F]{3,8}$/.test(en)) continue;            // 颜色字面量
    if (/^(text|bg|border|from|via|to)-/.test(en)) continue;  // tailwind 类名
    if (/^(w|h|min|max|p|m|gap|grid|flex)-/.test(en)) continue;
    if (/^(https?:|\.\/|\.\.\/|data:|blob:|file:)/.test(en)) continue;
    if (!entries.has(en)) entries.set(en, { kinds: new Set(), hits: 0, prio });
    const e = entries.get(en);
    e.kinds.add(kind);
    e.hits += 1;
    e.prio = Math.min(e.prio, prio);
  }
}

// 2b. children 数组里的字符串元素（主菜单等入口处大量使用），两种形态：
//     children:["TEXT", x]   → 数组首元素是字符串
//     jsx(...)," TEXT"]      → 数组末元素是字符串（前面是图标组件）
{
  const reArr = [
    /children:\["((?:[^"\\]|\\.)+)"(?:,[^\][]*)?\]/g,
    /\),"((?:[^"\\]|\\.)+)"\]/g,
    // 三元表达式：cond ? "A" : "B"（React 里最常见的分支文案形态）
    /\?"((?:[^"\\]|\\.)+)"\s*:\s*"((?:[^"\\]|\\.)+)"/g,
  ];
  const looksLikeText = (t) => {
    if (!/[A-Za-z]/.test(t) || t.length < 2) return false;
    if (/^#[0-9a-fA-F]{3,8}$/.test(t)) return false;
    if (/^(text|bg|border|from|via|to)-/.test(t)) return false;
    if (/^(https?:|\.\/|\.\.\/|data:|blob:|file:)/.test(t)) return false;
    if (/[a-z]{2,}-[a-z0-9]/.test(t)) return false; // tailwind/代码风格连字符
    if (/(rgba?\(|scale\(|translate\(|rotate\(|px solid|px |\binset\b|\brounded\b)/.test(t)) return false;
    if (/^(w|h)-\d/.test(t)) return false;
    return / /.test(t) || /^[A-Z0-9 %.:×₽+\/()'·\-&!?]+$/.test(t);
  };
  for (const re of reArr) {
    let ma;
    while ((ma = re.exec(src))) {
      for (const cand of [ma[1], ma[2]]) {
        if (!cand) continue;
        const en = norm(unescapeJs(cand));
        if (!looksLikeText(en)) continue;
        if (!entries.has(en)) entries.set(en, { kinds: new Set(), hits: 0, prio: 1 });
        const e = entries.get(en);
        e.kinds.add('ui');
        e.hits += 1;
        e.prio = Math.min(e.prio, 1);
      }
    }
  }
}

// 3. 读旧表，保留已有译文
const oldZh = new Map();
if (fs.existsSync(OUT)) {
  const old = parseCsv(fs.readFileSync(OUT, 'utf8'));
  for (const r of old) if (r.en && r.zh && r.zh.trim()) oldZh.set(norm(r.en), r.zh);
  console.log(`已有表：${old.length} 行，带译文 ${oldZh.size} 条`);
}

// 4. 输出
const rows = [...entries.entries()].map(([en, e]) => ({
  id: crypto.createHash('sha1').update(en).digest('hex').slice(0, 10),
  kind: [...e.kinds].sort((a, b) => KIND_RANK[a] - KIND_RANK[b]).join('+'),
  prio: e.prio,
  en,
  zh: oldZh.get(en) || '',
  hits: e.hits,
  note: '',
}));
rows.sort((a, b) => a.prio - b.prio || b.hits - a.hits || a.en.localeCompare(b.en));

fs.writeFileSync(OUT, toCsv(rows), 'utf8');

const byKind = {};
for (const r of rows) byKind[r.kind] = (byKind[r.kind] || 0) + 1;
console.log(`抽取完成：${rows.length} 条唯一字符串 → ${OUT}`);
console.log('按类型：', JSON.stringify(byKind));
const words = rows.reduce((a, r) => a + r.en.split(/\s+/).filter(Boolean).length, 0);
console.log(`总词数约 ${words}，已译 ${rows.filter((r) => r.zh).length} 条`);
}

// ---------- CSV ----------
function toCsv(rows) {
  const head = ['id', 'kind', 'en', 'zh', 'hits', 'note'];
  const q = (v) => {
    const s = String(v ?? '');
    return /[",\n\r]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
  };
  const lines = [head.join(',')];
  for (const r of rows) lines.push([r.id, r.kind, q(r.en), q(r.zh), r.hits, q(r.note)].join(','));
  return '\ufeff' + lines.join('\r\n') + '\r\n';
}

function parseCsv(text) {
  const s = text.replace(/^\ufeff/, '');
  const rows = [];
  let row = [], field = '', inQ = false;
  for (let i = 0; i < s.length; i++) {
    const c = s[i];
    if (inQ) {
      if (c === '"') {
        if (s[i + 1] === '"') { field += '"'; i++; } else inQ = false;
      } else field += c;
    } else if (c === '"') inQ = true;
    else if (c === ',') { row.push(field); field = ''; }
    else if (c === '\n') { row.push(field); rows.push(row); row = []; field = ''; }
    else if (c === '\r') { /* skip */ }
    else field += c;
  }
  if (field || row.length) { row.push(field); rows.push(row); }
  const head = rows.shift() || [];
  const idx = Object.fromEntries(head.map((h, i) => [h.trim(), i]));
  return rows.filter((r) => r.length > 1).map((r) => ({
    id: r[idx.id], kind: r[idx.kind], en: r[idx.en], zh: r[idx.zh], hits: r[idx.hits], note: r[idx.note],
  }));
}

module.exports = { parseCsv, toCsv };
