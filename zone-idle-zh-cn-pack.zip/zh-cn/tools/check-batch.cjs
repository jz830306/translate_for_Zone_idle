// 校验若干 batch 文件的键是否都能在 table.csv 中匹配
const fs = require('fs');
const path = require('path');
const { parseCsv } = require('./extract.cjs');

const ROOT = path.resolve(__dirname, '..');
const rows = parseCsv(fs.readFileSync(path.join(ROOT, 'table.csv'), 'utf8'));
const norm = (s) => s.replace(/\u00a0/g, ' ').replace(/\s+/g, ' ').trim();
const m = new Map(rows.map((r) => [norm(r.en), r]));

const files = process.argv.slice(2);
for (const f of files) {
  const p = path.join(ROOT, 'batches', f);
  const d = JSON.parse(fs.readFileSync(p, 'utf8'));
  const keys = Object.keys(d).filter((k) => !k.startsWith('_'));
  const miss = keys.filter((k) => !m.has(norm(k)));
  console.log(f + ' 条数 ' + keys.length + ' 未匹配 ' + miss.length);
  miss.forEach((x) => console.log('  ✗ ' + x.slice(0, 90)));
}
