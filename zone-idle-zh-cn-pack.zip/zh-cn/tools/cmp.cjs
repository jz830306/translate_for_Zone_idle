// 字符级对比：batch 键 vs table.csv 原文
const fs = require('fs');
const path = require('path');
const { parseCsv } = require('./extract.cjs');

const ROOT = path.resolve(__dirname, '..');
const rows = parseCsv(fs.readFileSync(path.join(ROOT, 'table.csv'), 'utf8'));
const [file, probe] = process.argv.slice(2);
const batch = JSON.parse(fs.readFileSync(path.join(ROOT, 'batches', file), 'utf8'));
const key = Object.keys(batch).find((k) => k.includes(probe));
const row = rows.find((r) => r.en.includes(probe));
if (!key || !row) { console.log('key=' + !!key + ' row=' + !!row); process.exit(0); }
console.log('batch 长度 ' + key.length + '  csv 长度 ' + row.en.length);
for (let i = 0; i < Math.max(key.length, row.en.length); i++) {
  if (key[i] !== row.en[i]) {
    console.log('首个差异 @' + i);
    console.log('  batch: ' + JSON.stringify(key.slice(Math.max(0, i - 30), i + 30)));
    console.log('  csv  : ' + JSON.stringify(row.en.slice(Math.max(0, i - 30), i + 30)));
    console.log('  codes: ' + key.charCodeAt(i) + ' vs ' + row.en.charCodeAt(i));
    break;
  }
}
