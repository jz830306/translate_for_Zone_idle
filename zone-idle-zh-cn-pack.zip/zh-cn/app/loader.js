/**
 * Zone Idle 中文化 —— 运行时词表注入层（外挂）
 *
 * 原理：不动游戏代码和资源，只在 DOM 层做「渲染后替换」。
 *   - 精确词表：英文原文 === 表项 → 替换为中文
 *   - 正则规则：处理带变量的动态串（如 "12 ROUNDS" → "12 发"）
 *   - MutationObserver 跟进 React 的后续重渲染
 * 词表放在 asar 外面（resources/zh-cn/table.json），改词表不需要重新打包，重启游戏即生效。
 *
 * 关闭：控制台执行 window.__zhOff() 或把 table.json 的 enabled 设为 false
 */
(function () {
  'use strict';

  var CONFIG = {
    tableFile: 'zh-cn/table.json',
    attributeNames: ['title', 'placeholder', 'aria-label', 'alt', 'data-tooltip'],
    debug: false,
  };

  function log() {
    if (CONFIG.debug && window.console) console.log.apply(console, ['[zh-cn]'].concat([].slice.call(arguments)));
  }

  // ---------- 1. 读词表 ----------
  var table = { enabled: true, entries: {}, rules: [] };
  function loadTable() {
    try {
      var fs = require('fs');
      var path = require('path');
      var candidates = [];
      if (typeof process !== 'undefined' && process.resourcesPath) {
        candidates.push(path.join(process.resourcesPath, CONFIG.tableFile));
      }
      candidates.push(path.join(__dirname, '..', '..', '..', '..', CONFIG.tableFile));
      for (var i = 0; i < candidates.length; i++) {
        if (fs.existsSync(candidates[i])) {
          var raw = JSON.parse(fs.readFileSync(candidates[i], 'utf8'));
          table = {
            enabled: raw.enabled !== false,
            entries: raw.entries || {},
            rules: (raw.rules || []).map(function (r) {
              return { re: new RegExp(r.pattern, r.flags || ''), zh: r.zh };
            }),
            source: candidates[i],
          };
          log('词表载入', candidates[i], Object.keys(table.entries).length, '条');
          return;
        }
      }
      console.warn('[zh-cn] 未找到词表，汉化未生效。查找路径：', candidates.join(' | '));
    } catch (err) {
      console.warn('[zh-cn] 词表载入失败：', err);
    }
  }

  // ---------- 2. 翻译函数 ----------
  var CJK = /[\u3400-\u9FFF\uF900-\uFAFF]/;

  function translateText(text) {
    if (!text) return null;
    var lead = text.match(/^\s*/)[0];
    var trail = text.match(/\s*$/)[0];
    var core = text.slice(lead.length, text.length - trail.length);
    if (!core) return null;
    core = core.replace(/\u00a0/g, ' ').replace(/\s+/g, ' ');

    // 最多 4 轮：规则产物可能仍含英文变量（如 LOCKED (REQ: PRESTIGE 1)），
    // 需要让后续规则/词表继续处理；无变化即停，防死循环。
    for (var round = 0; round < 4; round++) {
      var hit = table.entries[core];
      if (hit !== undefined && hit !== core) {
        core = hit;
        continue;
      }

      // 全大写/首字母大写变体：词表里常只存一种形态
      var lower = core.toLowerCase();
      if (lower !== core) {
        hit = table.entries['~' + lower];
        if (hit !== undefined && hit !== core) {
          core = hit;
          continue;
        }
      }

      var changed = false;
      for (var i = 0; i < table.rules.length; i++) {
        if (table.rules[i].re.test(core)) {
          var out = core.replace(table.rules[i].re, table.rules[i].zh);
          if (out !== core) {
            core = out;
            changed = true;
            break;
          }
        }
      }
      if (!changed) break;
    }
    return core === text ? null : lead + core + trail;
  }

  // 已经翻译过就不再处理（防循环）
  var translated = new WeakMap();

  function applyTextNode(node) {
    var v = node.nodeValue;
    if (!v || !/[A-Za-z]/.test(v)) return;
    if (translated.get(node) === v) return;
    var out = translateText(v);
    if (out === null || out === v) return;
    translated.set(node, out);
    node.nodeValue = out;
  }

  var SKIP_TAGS = { SCRIPT: 1, STYLE: 1, NOSCRIPT: 1, TEXTAREA: 1, CODE: 1, PRE: 1 };

  function walk(root) {
    if (!root) return;
    if (root.nodeType === 3) {
      if (root.parentNode && !SKIP_TAGS[root.parentNode.nodeName]) applyTextNode(root);
      return;
    }
    if (root.nodeType !== 1) return;
    if (SKIP_TAGS[root.nodeName]) return;

    applyAttributes(root);
    var walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, null);
    var n;
    while ((n = walker.nextNode())) {
      if (n.parentNode && !SKIP_TAGS[n.parentNode.nodeName]) applyTextNode(n);
    }
    if (root.querySelectorAll) {
      var els = root.querySelectorAll('[title],[placeholder],[aria-label],[alt],[data-tooltip]');
      for (var i = 0; i < els.length; i++) applyAttributes(els[i]);
    }
  }

  function applyAttributes(el) {
    for (var i = 0; i < CONFIG.attributeNames.length; i++) {
      var name = CONFIG.attributeNames[i];
      if (!el.hasAttribute || !el.hasAttribute(name)) continue;
      var v = el.getAttribute(name);
      if (!v || !/[A-Za-z]/.test(v)) continue;
      var out = translateText(v);
      if (out !== null && out !== v) el.setAttribute(name, out);
    }
  }

  // ---------- 3. 监听后续渲染 ----------
  var pending = new Set();
  var scheduled = false;

  function flush() {
    scheduled = false;
    var nodes = Array.from(pending);
    pending.clear();
    for (var i = 0; i < nodes.length; i++) {
      var n = nodes[i];
      if (!n || !n.isConnected) continue;
      if (n.nodeType === 3) {
        if (n.parentNode && !SKIP_TAGS[n.parentNode.nodeName]) applyTextNode(n);
      } else if (n.nodeType === 1) {
        walk(n);
      }
    }
  }

  function schedule(node) {
    pending.add(node);
    if (scheduled) return;
    scheduled = true;
    // 微任务批量处理：窗口失焦/最小化时 rAF 会被冻结，微任务不会
    Promise.resolve().then(flush);
  }

  var observer = new MutationObserver(function (records) {
    for (var i = 0; i < records.length; i++) {
      var r = records[i];
      if (r.type === 'characterData') schedule(r.target);
      else if (r.type === 'attributes') schedule(r.target);
      else for (var j = 0; j < r.addedNodes.length; j++) schedule(r.addedNodes[j]);
    }
  });

  // ---------- 4. 启动 ----------
  function start() {
    loadTable();
    if (!table.enabled) {
      console.warn('[zh-cn] 词表 enabled=false，跳过汉化');
      return;
    }

    // 中文字体回退：拉丁字符仍用原字体，汉字走系统中文字体
    var style = document.createElement('style');
    style.id = 'zh-cn-font';
    style.textContent =
      ':root{--zh-font:"Microsoft YaHei UI","Microsoft YaHei","PingFang SC","Noto Sans SC","Source Han Sans SC",sans-serif}' +
      'body,button,input,select,textarea{font-family:"Share Tech Mono",var(--zh-font),monospace}';
    document.head.appendChild(style);

    document.documentElement.lang = 'zh-CN';
    walk(document.body);
    observer.observe(document.documentElement, {
      childList: true,
      subtree: true,
      characterData: true,
      attributes: true,
      attributeFilter: CONFIG.attributeNames,
    });
    log('已启动，监听中');
  }

  window.__zhOff = function () {
    observer.disconnect();
    console.warn('[zh-cn] 已停止（刷新后恢复）');
  };
  window.__zhStats = function () {
    return { entries: Object.keys(table.entries).length, rules: table.rules.length, source: table.source };
  };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', start, { once: true });
  } else {
    start();
  }
})();
