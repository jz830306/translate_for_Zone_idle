# Zone Idle 外挂式中文化（zh-cn）

不动游戏逻辑，通过「运行时 DOM 词表替换」实现汉化。**没有修改任何游戏参数**（数值、掉落、平衡、存档结构一律未碰）。

## 到底改了游戏里的什么（可自查）

游戏本体 `resources/app.asar` 被重写过一次，但逐文件哈希比对后，差异只有两项：

| 项目 | 情况 |
|---|---|
| 文件总数 | 4570 → 4571（**只多 1 个**） |
| 新增 | `dist/zh-cn/loader.js`（7635 字节，就是本工程 `app/loader.js` 的拷贝） |
| 修改 | `dist/index.html`，4373 → 4420 字节 |
| 删除 | 0 |
| 其余 4570 个文件 | SHA1 逐字节一致（打包 JS、图片、音频、主进程代码都没动） |

`dist/index.html` 的全部改动就两行：

```diff
- <html lang="en">
+ <html lang="zh-CN">
+ <script src="./zh-cn/loader.js"></script>
```

> 为什么要碰 asar：Electron 的页面从 `app.asar/dist/index.html` 加载，路径在 `main.js` 里写死，
> 没有任何外部注入入口。要让代码进渲染进程，最小代价就是上面这一行 script 标签。
> 翻译数据本身全在 asar 外面（`resources/zh-cn/table.json`），所以后续改译文不需要再碰游戏文件。

自查命令（25 秒左右，会重算 95MB 的所有文件哈希）：

```
node tools/diff.cjs
```

正常输出应为 `结论: ✔ 只注入了加载器，游戏本体逻辑未被改动`。

## 目录结构

```
zh-cn/                      ← 汉化工程（本目录）
  table.csv                 ← 翻译总表（唯一人工编辑源）
  rules.json                ← 带变量的动态串规则（正则）
  batches/*.json            ← 翻译批次（merge 工具的输入，可继续追加）
  app/loader.js             ← 运行时注入层（打进 asar，基本不用改）
  tools/                    ← 构建工具链（Node 脚本，无外部依赖）
    diff.cjs                ← 逐文件比对原版与当前 asar（自查改动范围）
resources/
  zh-cn/table.json          ← 运行时词表（build 产物，改完重启游戏即生效）
  app.asar.zh-backup        ← 原版包备份（patch 首次运行时自动创建）
```

## 日常使用

改翻译只需要两步（不需要重新打包 asar）：

1. 编辑 `table.csv`（或往 `batches/` 加一个 JSON，然后跑 merge）
2. `node tools/build.cjs` → 重启游戏

## 工具链

| 命令 | 作用 |
|---|---|
| `node tools/extract.cjs` | 从 app.asar 的打包 JS 里抽出全部可翻译字符串，重建 table.csv（保留已有译文） |
| `node tools/merge.cjs` | 把 batches/*.json 按英文原文合并进 table.csv |
| `node tools/build.cjs` | table.csv + rules.json → resources/zh-cn/table.json（运行时词表） |
| `node tools/patch.cjs` | 安装/更新注入层（自动备份原包；被占用时自动改原地覆写） |
| `node tools/patch.cjs --restore` | 还原原版 app.asar |
| `node tools/patch.cjs --check` | 查看当前安装状态 |
| `node tools/diff.cjs` | 逐文件比对原版备份与当前 asar，核对改动范围 |
| `node tools/dump.cjs <kind>` | 导出某类未译条目到 pending/（配批量补翻用） |
| `node tools/check-batch.cjs a.json b.json` | 校验批次文件的键能否全部匹配 table.csv |
| `node tools/dup.cjs [关键词]` | 查找 table.csv 中的重复原文 |
| `node tools/scan-keys.cjs` / `list-kind.cjs` / `list-ui.cjs` | 浏览待译字符串 |
| `node tools/cdp.cjs eval/shot/text/reload` | 连接运行中的游戏（需带 --remote-debugging-port 启动）做验证 |

## 词表格式

`table.csv` 列：`id, kind, en, zh, hits, note`

- `kind`：`ui`（界面文字）/ `data`（物品名与描述）/ `task`（任务成败文案）/ `narr`（旁白）
- `en` 是匹配键：渲染出的文本去首尾空白、折叠连续空白、不间断空格转普通空格后与之精确匹配
- 大小写不敏感的兜底：构建时自动生成全小写别名，界面上的 CSS 大写变形（如 `ENTER HIDEOUT`）也能命中
- `zh` 留空 = 不翻译，原样显示英文，不会报错

`rules.json`：`{ "pattern": "^WELCOME BACK, (.+)$", "zh": "欢迎回来，$1" }`，处理带变量的动态串。
注意正则不要带 `g` 标志（flags 字段默认空）。

## 当前状态（2026-10-22 第二轮补翻后）

- 界面框架（ui）：**1817/1820**（剩余 3 条是 CSS 类名等非文本噪声，无需翻译）
- 物品名/描述（data）：**766/766 = 100%**（含 400+ 条场景/事件长描述、商人委托台词）
- 任务文案（task）：**847/847 = 100%**（突袭事件的成功/失败/危险提示全量覆盖）
- 旁白（narr）：**46/46 = 100%**（教学引导、系统状态提示）

合计 3476/3479（99.9%），未覆盖的 3 条均为非文本噪声。

### 补充词条 table-extra.json

有些文案是游戏在 JS 层**拼好/缩短后**才渲染的（如仓库网格里的缩略名 `Bandage`、`+24 SLOTS · LV2`、`TACTICAL FEED : THE CORDON`），
它们在 table.csv 里不存在。这类词条放进 `zh-cn/table-extra.json`（英文原文 → 中文），build 时自动并入词表。

### 动态串规则（rules.json，22 条）

规则现在支持**链式匹配**：第一条规则的输出若仍含英文变量（如 `已锁定（需要：PRESTIGE 1）`），
会被后续规则继续处理（→ `已锁定（需要：声望 1）`）。新增规则后只需 `build` + 重启游戏。

剩余部分的补翻流程：`node tools/dump.cjs <kind>` 导出未译条目到 `pending/` → 译文写进 `batches/` → merge → build → 重启。

## 已知边界

- 极少数运行时拼出来的字符串（模板串）需要配 rules 才能翻
- 纯 Canvas 绘制的文字不走 DOM，翻不到（本游戏没有）
- Steam 校验游戏文件会把 app.asar 还原成英文原版：重新 `node tools/patch.cjs` 即可恢复汉化
- 字体：拉丁字符保持原来的 Share Tech Mono / VT323 风格，汉字回退到系统中文字体（微软雅黑等）
