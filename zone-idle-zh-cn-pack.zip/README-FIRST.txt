ZONE IDLE 外挂式中文化安装包
================================

这是《Zone Idle Demo》的完整外挂汉化包：不改数值、不改掉落、不改存档结构，
只做「渲染后文本替换」。逐文件哈希可自查（见 zh-cn/README.md）。

安装步骤
--------
1. 把本压缩包解压到游戏根目录（即 Zone Idle Demo.exe 所在目录），
   解压后应出现：
     zh-cn\               （汉化工程）
     resources\zh-cn\     （运行时词表，含 table.json）
     README-FIRST.txt     （本文件）
2. 确认 resources\app.asar.zh-backup 存在（原版备份）。
   若没有：运行  node zh-cn\tools\patch.cjs  完成注入并自动备份。
3. 启动游戏即是中文。

更新译文
--------
1. 编辑 zh-cn\batches\*.json 或 zh-cn\table.csv / table-extra.json
2. node zh-cn\tools\merge.cjs
3. node zh-cn\tools\build.cjs
4. 重启游戏（不需要重新打包 asar）

还原英文原版
------------
node zh-cn\tools\patch.cjs --restore

自查改动范围
------------
node zh-cn\tools\diff.cjs
（结论应为：只新增 dist/zh-cn/loader.js、只修改 dist/index.html 两行）

需要 Node.js（任意较新版本，无需联网、无第三方依赖）。

进度：界面 100% / 物品与描述 100% / 任务事件文案 100% / 旁白引导 100%。
